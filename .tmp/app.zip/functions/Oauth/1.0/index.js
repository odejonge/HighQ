import templayed from "./templayed";

const Oauth = async ({tokenUri, authUri, client, secret,url,
    method,
    body,
    headers = [],
    protocol,
    variables,
    queryParameters = [],}) => {
    
}

export default Oauth;